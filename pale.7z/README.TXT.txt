
Copy the EXE program to your PALE directory

Copy the DLL to your WINDOWS/SYSTEM32 directory

You do NOT need Winsck.ocx (this is for networking, which is NOT working at present)

